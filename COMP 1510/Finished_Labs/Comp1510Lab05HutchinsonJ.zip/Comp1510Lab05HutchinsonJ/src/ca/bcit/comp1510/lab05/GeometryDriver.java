package ca.bcit.comp1510.lab05;

import java.util.Scanner;
import java.text.DecimalFormat;

/**
 * Driver class for Sphere, Cube, and Cone Classes
 * Prints out special calculations for each class.
 * @author Jayden H
 * @version 1.0
 */
public class GeometryDriver {

    /**
     * Drives the program.
     * @param args unused
     */
    public static void main(String[] args) {
        
        // Declarations
        DecimalFormat twoDecimals = new DecimalFormat("###,###.###");
        Scanner input = new Scanner(System.in);
        
        // SPHERE OBJECT
        
        // Gets user input to create a Sphere Object
        // Input is assiged to x, y, z coordinates and radius
        System.out.print("Enter the Radius of a Sphere: ");
        double radius = input.nextDouble();
        System.out.print("Enter an X Coordinate: ");
        double x = input.nextDouble();
        System.out.print("Enter a Y Coordinate: ");
        double y = input.nextDouble();
        System.out.print("Enter a Z Coordinate: ");
        double z = input.nextDouble();
        
        // Creates a Sphere Object with user input 
        Sphere userSphere = new Sphere(x, y, z, radius);
        
        // Prints the surface area and volume of the Sphere
        System.out.println("\nSphere Surface Area: "
                         + twoDecimals.format(userSphere.getSurfaceArea())
                         + "\nSphere Volume: " 
                         + twoDecimals.format(userSphere.getVolume()));
        
        
        // CUBE OBJECT
        
        // Gets user input to create a Cube Object
        // Inputs are assigned to x, y, z coordinates and edge length
        System.out.print("\nEnter the Edge Length of a Cube: ");
        double edgeLength = input.nextDouble();
        System.out.print("Enter an X Coordinate: ");
        x = input.nextDouble();
        System.out.print("Enter a Y Coordinate: ");
        y = input.nextDouble();
        System.out.print("Enter a Z Coordinate: ");
        z = input.nextDouble();
        
        // Creates a Cube Object with user input
        Cube userCube = new Cube(edgeLength, x, y, z);
        
        // Prints the surface area, volume, and tow diagonals of the Cube
        System.out.println("\nCube Surface Area: " 
                         + twoDecimals.format(userCube.getSurfaceArea())
                         + "\nCube Volume: " 
                         + twoDecimals.format(userCube.getVolume())
                         + "\nCube Face Diagonal: " 
                         + twoDecimals.format(userCube.getFaceDiagonal())
                         + "\nCube Space Diagonal: " 
                         + twoDecimals.format(userCube.getSpaceDiagonal()));
        
        // CONE OBJECT 
        
        // Gets user input to create a Cone Object
        // Inputs assinged to radius and height
        System.out.print("\nEnter the Radius of a Cone: ");
        radius = input.nextDouble();
        System.out.print("Enter the Height of the Cone: ");
        double height = input.nextDouble();
        
        // Prints the volume slant height and area 
        Cone userCone = new Cone(radius, height);
        System.out.println("\nCone Volume: " 
                         + twoDecimals.format(userCone.getVolume())
                         + "\nCone Slant Height: " 
                         + twoDecimals.format(userCone.getSlantHeight())
                         + "\nCone Surface Area: " 
                         + twoDecimals.format(userCone.getSurfaceArea()));
        
        
        
        
        input.close();
    }

}
