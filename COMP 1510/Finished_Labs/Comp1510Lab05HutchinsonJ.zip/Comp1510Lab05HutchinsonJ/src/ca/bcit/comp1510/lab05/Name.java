package ca.bcit.comp1510.lab05;

/** Class used to make an object out of first, middle, and last name.
 * @author Jayden H
 * @version 1.0
 */

public class Name {
    
    /** Declares the variable for first name. */
    private String firstName;
    
    /** Declares the variable for middle name. */
    private String middleName;
    
    /** Declares the variable for last name. */
    private String lastName;
    
    /** Constructor for the Name Class.
     * 
     * @param newFirstName sets the first name
     * @param newMiddleName sets the middle name
     * @param newLastName sets the last name
     */
    public Name(String newFirstName, String newMiddleName, String newLastName) {
        firstName = newFirstName;
        middleName = newMiddleName;
        lastName = newLastName;
    }
    
    /** Getter for first name.
     * 
     * @return firstName Strings
     */
    public String getFirstName() {
        return firstName;
    }
    
    /** Getter for middle name.
     * 
     * @return middleName String
     */
    public String getMiddleName() {
        return middleName;
    }
    
    /** Getter for last name.
     * 
     * @return lastName String
     */
    public String getLastName() {
        return lastName;
    }
    
    /** Setter for first name.
     * 
     * @param newFirstName sets the first name
     */
    public void setFirstName(String newFirstName) {
        firstName = newFirstName;
    }
    
    /** Setter for middle name.
     * 
     * @param newmiddleName sets the middle name
     */
    public void setMiddleName(String newmiddleName) {
        middleName = newmiddleName;
    }
    
    /** Setter for last name.
     * 
     * @param newlastName sets the last name
     */
    public void setLastName(String newlastName) {
        lastName = newlastName;
    }
    
    /**
     * Calculates the length of the name.
     * @return name length
     */
    public int length() {
        int firstNameLength = firstName.length(); 
        int middleNameLength = middleName.length();
        int lastNameLength = lastName.length();
        return firstNameLength + middleNameLength + lastNameLength;
    }
    
    /**
     * Turns the first initials to a string all capitalized.
     * @return first initial of first, middle and last name capitalized
     */
    public String initials() {
        Character firstInitial = firstName.charAt(0);
        Character middleInitial = middleName.charAt(0);
        Character lastInitial = lastName.charAt(0);
        return firstInitial.toString().toUpperCase() 
             + middleInitial.toString().toUpperCase()  
             + lastInitial.toString().toUpperCase();
    }
    
    /** 
     * Gets a character from the full name at the chosen index.
     * @param n character to return
     * @return nth character
     */
    public char getCharacter(int n) {
        String fullName = firstName + middleName + lastName;
        char userChar = fullName.charAt(n);
        return userChar;
    }
    
    /**
     * Orders the names in last name, first name, middle name order.
     * @return full name
     */
    public String professionalLayout() {
        String layout = lastName + ", " + firstName + " " + middleName;
        return layout;
    }
    
    /** 
     * Compares the input name to the object name.
     * @param name compared to first name 
     * @return true or false
     */
    public boolean equals(String name) {
        boolean result = firstName.equals(name);
        return result;
    }
    
    /**
     * Compares two instances of the object Name.
     * @param newName Name Object 
     * @return true or false if they are the same
     */
    public boolean fullNameEquals(Name newName) {
        
        boolean compareFirst = firstName.equals(newName.getFirstName());
        boolean compareMiddle = middleName.equals(newName.getMiddleName());
        boolean compareLast = lastName.equals(newName.getLastName());
        
        if (compareFirst && compareMiddle && compareLast) {     
            return true;
        }
        return false;
    }
    
    /** Converts the Name Class objects to a string.
     * 
     * @return String of Name objects
     */
    public String toString() {
        return firstName + " " + middleName + " " + lastName;
    }
}

    

