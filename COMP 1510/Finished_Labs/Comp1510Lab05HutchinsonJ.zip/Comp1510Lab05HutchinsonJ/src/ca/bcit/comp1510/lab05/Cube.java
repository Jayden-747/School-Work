package ca.bcit.comp1510.lab05;

/**
 * Creates a Cube Object with the coordinates and 
 * dimensions of the Cube. 
 * @author Jayden H 
 * @version 1.0
 */

public class Cube {

    /**
     * X-Coordinate of the Cube.
     */
    private static double xCoordinate;
    
    /**
     * Y-Coordinate of the Cube.
     */
    private static double yCoordinate;
    
    /**
     * Z-Coordinate of the Cube.
     */
    private static double zCoordinate;
    
    /**
     * Edge Length for all sides of the Cube.
     */
    private double edgeLength;
    
    /** 
     * Used in calculating the surface area.
     */
    private final double sURFACEAREASIX = 6;
    
    /** 
     * Used in calculating surface area.
     */
    private final double pOW2 = 2;
    
    /** 
     * Used in calculating the volume.
     */
    private final double pOW3 = 3;
    
    /** 
     * Used in calculating the face diagonal.
     */
    private final double sQRT2 = Math.sqrt(2);
    
    /**
     * Used in calculating the space diagonal.
     */
    private final double sQRT3 = Math.sqrt(3);
    
    
    /**
     * Constructor that assigns the x, y ,z coordinates
     * and edge length.
     * @param x assigned to X-Coordinate
     * @param y assigned to Y-Coordinate
     * @param z assigned to Z-Coordinate
     * @param edge assigned to Edge Length
     */
    public Cube(double x, double y, double z, double edge) {
        xCoordinate = x;
        yCoordinate = y;
        zCoordinate = z;
        edgeLength = edge; 
    }

    /**
     * Getter for X-Coordinate.
     * @return X-Coordinate value
     */
    public double getXCoordinate() {
        return xCoordinate;
    }
    
    /**
     * Getter for Y-Coordinate.
     * @return Y-Coordinate value
     */
    public double getYCoordinate() {
        return yCoordinate;
    }
    
    /**
     * Getter for Z-Coordinate.
     * @return Z-Coordinate value
     */
    public double getZCoordinate() {
        return zCoordinate;
    }

    /**
     * Getter for Edge Length.
     * @return Edge Length value
     */
    public double getEdgeLength() {
        return edgeLength;
    }

    /**
     * Setter for X-Coordinate.
     * @param x assigned to X-Coordinate
     */
    public void setXCoordinate(double x) {
        xCoordinate = x;
    }
    
    /**
     * Setter for Y-Coordinate.
     * @param y assigned to Y-Coordinate
     */
    public void setYCoordinate(double y) {
        yCoordinate = y;
    }
    
    /**
     * Setter for Z-Coordinate.
     * @param z assigned to Z-Coordinate
     */
    public void setZCoordinate(double z) {
        zCoordinate = z;
    }
    
    /**
     * Setter for Edge Length.
     * @param edge assigned to Edge Length
     */
    public void setEdgeLength(double edge) {
        edgeLength = edge;
    }
    
    /**
     * Getter for the Surface Area.
     * @return surface area
     */
    public double getSurfaceArea() {
        double surfaceArea = sURFACEAREASIX * Math.pow(edgeLength, pOW2);
        return surfaceArea;
    }
    
    /** 
     * Getter for Volume.
     * @return volume
     */
    public double getVolume() {
        double volume = Math.pow(edgeLength, pOW3);
        return volume;
    }
    
    /**
     * Getter for Face Diagonal.
     * @return face diagonal
     */
    public double getFaceDiagonal() {
        double faceDiagonal = sQRT2 * edgeLength;
        return faceDiagonal;
    }
      
    /** 
     * Getter for Space Diagonal.
     * @return space diagonal
     */
    public double getSpaceDiagonal() {
        double spaceDiagonal = sQRT3 * edgeLength;
        return spaceDiagonal;
    }
    
    /** 
     * toString Method.
     * @return all variables of the Cube Object
     */
    public String toString() {
        return Double.toString(xCoordinate + yCoordinate + zCoordinate
                             + edgeLength + getSurfaceArea() 
                             + getVolume() + getFaceDiagonal());
    }
}
