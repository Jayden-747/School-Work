package ca.bcit.comp1510.lab05;

/**
 * Class used to create a Cone Object 
 * using the radius and height.
 * @author Jayden H
 * @version 1.0
 */
public class Cone {
    
    /** 
     * Radius of the Cone.
     */
    private double radius;
    
    /** 
     * Height of the Cone.
     */
    private double height;
    
    /** 
     * Used in calculating the volume of the Cone.
     */
    private final double volume13 = 0.3333333333333;
    
    /**
     * Used in calculating Cone dimensions.
     */
    private final double pow2 = 2;
    
    /** 
     * Constructor for the Cone.
     * @param r sets the radius 
     * @param h sets the height 
     */
    public Cone(double r, double h) {
        radius = r;
        height = h;
    }
    
    /**
     * Getter for the radius.
     * @return radius
     */
    public double getRadius() {
        return radius;
    }
    
    /** 
     * Getter for the height.
     * @return height
     */
    public double getHeight() {
        return height;
    }
    
    /** 
     * Setter for the radius.
     * @param r sets the radius
     */
    public void setRadius(double r) {
        radius = r;
    }
    
    /**
     * Setter for the height.
     * @param h sets the height
     */
    public void setHeight(double h) {
        height = h;
    }
    
    /**
     * Getter for the volume.
     * @return volume
     */
    public double getVolume() {
        double volume = volume13 * ((Math.PI * Math.pow(radius, 2) * height));
        return volume;
    }
    
    /** 
     * Getter for the slant height.
     * @return slant height
     */
    public double getSlantHeight() {
        double slantHeight = Math.sqrt(Math.pow(radius, pow2) 
                                     + Math.pow(height, pow2));
        return slantHeight;
    }
    
    /**
     * Getter for the surface area. 
     * @return surface area
     */
    public double getSurfaceArea() {
        double surfaceArea = (Math.PI * Math.pow(radius, pow2)) 
                       + (Math.PI * radius) * Math.sqrt(Math.pow(radius, pow2) 
                            + Math.pow(height, pow2));
        return surfaceArea;
    }
    
    /**
     * toString method.
     * @return the variables of the cone in a string
     */
    public String toString() {
        return Double.toString(radius + height + getVolume() 
                             + getHeight() + getSurfaceArea());
    }
    
}
