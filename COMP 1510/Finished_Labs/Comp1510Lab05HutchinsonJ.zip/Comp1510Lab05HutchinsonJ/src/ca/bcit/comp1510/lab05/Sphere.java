package ca.bcit.comp1510.lab05;

/** 
 * Creates a Sphere Object with the coordinates and 
 * dimensions of the Sphere.
 * @author Jayden H
 * @version 1.0
 */

public class Sphere {
    
    /**
     * X-Coordinate of the Sphere.
     */
    private static double xCoordinate;
    
    /**
     * Y-Coordinate of the Sphere.
     */
    private static double yCoordinate;
    
    /**
     * Z-Coordinate of the Sphere.
     */
    private static double zCoordinate;
    
    /**
     * Radius of the Sphere.
     */
    private static double radius;
    
    /**
     * Used to calculate the Volume of the Sphere.
     */
    private static final double VOLUME_4DIV3 = 1.333333333333;
    
    /**
     * Used to Calculate the Surface Area of the Sphere.
     */
    private static final double SURFACE_AREA4 = 4;
    
    /**
     * Used as the power of the radius for the Surface Area.
     */
    private static final double POW2 = 2;
    
    /**
     * Used as the power of the radius for the Volume.
     */
    private static final double POW3 = 3;

    /**
     * Constructor for the Sphere Class.
     * @param x assigned to X-Coordinate
     * @param y assigned to Y-Coordinate
     * @param z assigned to Z-Coordinate
     * @param r assigned to Radius
     */
    public Sphere(double x, double y, double z, double r) {
        xCoordinate = x;
        yCoordinate = y;
        zCoordinate = z;
        radius = r;
    }
    
    /**
     * Getter for X-Coordinate.
     * @return X-Coordinate value
     */
    public double getXCoordinate() {
        return xCoordinate;
    }
    
    /**
     * Getter for Y-Coordinate.
     * @return Y-Coordinate value
     */
    public double getYCoordinate() {
        return yCoordinate;
    }
    
    /**
     * Getter for Z-Coordinate.
     * @return Z-Coordinate value
     */
    public double getZCoordinate() {
        return zCoordinate;
    }
    
    /**
     * Getter for Radius.
     * @return Radius value
     */
    public double getRadius() {
        return radius;
    }
    
    /**
     * Setter for X-Coordinate.
     * @param x assigned to X-Coordinate
     */
    public void setXCoordinate(double x) {
        xCoordinate = x;
    }
    
    /**
     * Setter for Y-Coordinate.
     * @param y assigned to Y-Coordinate
     */
    public void setYCoordinate(double y) {
        yCoordinate = y;
    }
    
    /**
     * Setter for Z-Coordinate.
     * @param z assigned to Z-Coordinate
     */
    public void setZCoordinate(double z) {
        zCoordinate = z;
    }
    
    /**
     * Setter for Radius.
     * @param r assigned to Radius
     */
    public void setRadius(double r) {
        radius = r;
    } 
    
    /** 
     * Calculates the Surface Area of the Sphere.
     * @return Surface Area of the Sphere
     */
    public double getSurfaceArea() {
        double surfaceArea = SURFACE_AREA4 * (Math.PI * Math.pow(radius, POW2));
        return surfaceArea;
    }
    
    /**
     * Calculates the Volume of the Sphere.
     * @return Volume of the Sphere
     */
    public double getVolume() {
        double volume = VOLUME_4DIV3 * Math.PI * Math.pow(radius, POW3);
        return volume;
    }
    
    /**
     * Converts the variables of the Sphere Object to a string.
     * @return Sphere as a String
     */
    public String toString() {
        return "X-Coordinate: " + xCoordinate 
             + "Y-Coordinate: " + yCoordinate 
             + "Z-Coordinate: " + zCoordinate 
             + "Radius: " + radius;
    }

}





