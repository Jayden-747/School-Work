package ca.bcit.comp1510.lab05;

/**
 * Driver for the Name Class 
 * Creates the object using the first, middle, and last name
 * of the user.
 * @author Jayden H
 * @version 1.0
 */
public class NameDriver {

    /**
     * Drives the program.
     * @param args unused
     */
    public static void main(String[] args) {
        
        // Constructos of two Name objects 
        Name myName = new Name("Jayden", "Brian", "Hutchinson");
        Name secondName = new Name("Jayden", "Brian", "Hutchinson");
                
        // Gets the length of the object String
        int length = myName.length();
        
        // Gets the initials of the object variables
        String initials = myName.initials();
        
        // Gets the character at the given integer place
        char character = myName.getCharacter(0);
        
        // Applies a layout to the name object
        String layout = myName.professionalLayout();
        
        // Compares the two created objects in the method
        boolean compare = myName.fullNameEquals(secondName);

        // Prints all returned methods of the main method
        System.out.println("Length: " + length
                         + "\nInitials: " + initials
                         + "\nCharacter: " + character
                         + "\nLayout: " + layout
                         + "\n\nNames are Equal: \n"
                         + compare);
    }

}
