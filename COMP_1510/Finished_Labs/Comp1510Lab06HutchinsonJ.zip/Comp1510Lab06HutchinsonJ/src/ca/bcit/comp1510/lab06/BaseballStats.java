package ca.bcit.comp1510.lab06;

import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;

/**
 * Reads baseball data in from a comma delimited file. Each line 
 * of the file contains a name followed by a list of symbols
 * indicating the result of each at bat: h for hit, o for out,
 * w for walk, s for sacrifice. Statistics are computed and
 * printed for each player.
 * @author blink
 * @version 1.0
 */

public class BaseballStats {
    
    /**
     * Reads baseball stats from a file and counts
     * total hits, outs, walks, and sacrifice flies
     * for each player.
     * @param args unused
     */
    
    public static void main(String[] args) throws FileNotFoundException {
        
        // DECLARATIONS
        Scanner fileScan;
        Scanner lineScan;
        String fileName;
        Scanner scan = new Scanner(System.in);
        
        
        // Prompts for and reads the specified file
        System.out.print("Enter the name of the input file: ");
        fileName = scan.nextLine();
        fileScan = new Scanner(new File(fileName));
        
        // Scans each line and tallies the data into a variable,
        // After each line it prints the data and the program ends
        // when there are no more lines.
        while (fileScan.hasNextLine()) {
            
            String line = fileScan.nextLine();
            lineScan = new Scanner(line);
            lineScan.useDelimiter(",");
            
            
            if (lineScan.hasNext()) {
                String name = lineScan.next();  
                int out = 0;
                int hit = 0; 
                int sacrifice = 0; 
                int walk = 0;
                
                while (lineScan.hasNextLine()) {
                    String stats = lineScan.next();
                    if (stats.equals("o")) {
                        out++;
                    } else if (stats.equals("h")) {
                        hit++;
                    } else if (stats.equals("s")) {
                        sacrifice++;
                    } else if (stats.equals("w")) {
                        walk++;
                    }
                }
        
                System.out.println("\nPlayer: " + name 
                                 + "\nOuts: " + out
                                 + "\nHits: " + hit 
                                 + "\nSacrifices: " + sacrifice
                                 + "\nWalks: " + walk);
        
        
            }
            scan.close();
        }
    }
}
