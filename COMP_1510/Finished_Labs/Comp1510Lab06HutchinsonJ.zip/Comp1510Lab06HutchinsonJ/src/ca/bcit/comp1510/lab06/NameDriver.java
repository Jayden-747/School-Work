package ca.bcit.comp1510.lab06;

/**
 * Driver for the Name Class 
 * Creates the object using the first, middle, and last name
 * of the user.
 * @author Jayden H
 * @version 1.0
 */
public class NameDriver {
    
    /**
     *  Used in the getCharacter argument.
     */
    static final int THIRTY = 30;

    /**
     * Drives the program.
     * @param args unused
     */
    public static void main(String[] args) {
        
        // Prints out my name after capitalizing the first letters.
        Name myName = new Name("jayden", "brian", "hutchinson");
        System.out.println(myName);
        
        // Prints out the name with capital first 
        // letter and lower case for the rest.
        Name newName = new Name("BiLl", "WhItE", "MiLlEr");
        System.out.println(newName);
        
        // Sets a name with empty string and assigns a 
        // pre made name to the variables to print
        Name emptyName = new Name("     ", "      ", "      ");
        System.out.println(emptyName);
        
        // Sets the name for the empty name and capitalizes
        // the first letter
        emptyName.setFirstName("steve");
        emptyName.setMiddleName("austin");
        emptyName.setLastName("matthews");
        System.out.println(emptyName);
            
        // Prints the @ character because the number 
        // given is larger than the length of the name.
        char at = myName.getCharacter(THIRTY);
        System.out.println(at);
        
        
        System.out.println();
        
        
    }
}
