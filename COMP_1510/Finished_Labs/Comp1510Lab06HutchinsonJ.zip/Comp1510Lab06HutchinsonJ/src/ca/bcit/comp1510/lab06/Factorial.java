package ca.bcit.comp1510.lab06;

import java.util.Scanner;

/** Calculates the factorial of a given number.
 * @author Jayden H.
 * @version 1.0
 */
public class Factorial {

    /** Runs the program.
     * @param args unused
     */
    public static void main(String[] args) {
        
        // DECLARATIONS
        Scanner input = new Scanner(System.in);
        int product = 1;
        
        // Request an integer from the user
        System.out.print("Enter a positive Number: ");
        
        /* If the input reads an integer, assign the value to userNumber
           Else remind user to input an integer again */
        while (input.hasNext()) {
            while (input.hasNextInt()) {
                int givenNumber = Integer.parseInt(input.next());
                if (givenNumber < 0) {
                    System.out.print("Enter a positive Number: "); 
                } else {
                    for (int i = 1; i != givenNumber + 1; i++) {
                        product = product * i;
                    }
                    System.out.println(product);
                    input.close();
                    return;
                }
            } if (input.hasNext()) {
                System.out.print("Given value must be a number!"
                        + "\nEnter a positive Number: ");
                input.next();
            }
        }
        input.close();
    }
}

