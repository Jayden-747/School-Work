package ca.bcit.comp1510.lab07;

/** 
 * Used to practice the debugging features of eclipse.
 * @author Jayden H 
 * @version 1.0
 */
public class DebugStar {
    
    /**
     * used in main method.
     */
    
    private static final int SIX = 6;

    /** 
     * used in main method.
     */
    
    private static final int SEVEN = 7;
    
    
    /** 
     * Drives the program.
     * @param args unused
     */
    public static void main(String[] args) {
        run("+", SIX, SEVEN);
        run("-", SIX, SEVEN);
        run(SIX);

    }
    
    private static Operation getOperation(final String key) {
        final Operation operation;
        if (key.equals("+")) {
            operation = new Add();
        } else {
            operation = new Subtract();
        }
        return (operation);
    }
    
    private static void run(final String key, final int a, final int b) {
        final Operation operation;
        final int result;
        operation = getOperation(key);
        result = operation.perform(a, b);
        System.out.println("result = " + result);
    }
    
    private static void run(final int n) {
        final Factorial factorial;
        final int result;
        factorial = new Factorial();
        result = factorial.perform(n);
        System.out.println("result = " + result);
    }

}

interface Operation {
    int perform(int a, int b);
}

class Add implements Operation {
    @Override
    public int perform(final int a, final int b) {
        return (a + b);
    }
}

class Subtract implements Operation {
    @Override
    public int perform(final int a, final int b) {
        return (a - b);
    }
}

class Factorial {
    int perform(final int n) {
        int ret;
        ret = 1;
        for (int i = 1; i < n; i++) {
            ret *= i;
        }
        return (ret);
    }
}
