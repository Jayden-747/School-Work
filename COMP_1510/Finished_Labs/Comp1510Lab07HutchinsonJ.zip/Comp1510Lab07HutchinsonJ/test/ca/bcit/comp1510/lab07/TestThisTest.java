package ca.bcit.comp1510.lab07;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;


class TestThisTest {
    
    private TestThis testThis = new TestThis();

    @Test
    void testLargestIntIntInt() {
        assertEquals(6, testThis.largest(4, 5, 6));  
    }
    
    @Test
    void testLargestIntIntInt2() {
        assertEquals(-4, testThis.largest(-4, -5, -6));  
    }
    
    @Test
    void testLargestIntIntInt3() {
        assertEquals(2048, testThis.largest(20, 150, 2048));  
    }
    
    @Test
    void testLargestIntIntInt4() {
        assertEquals(75, testThis.largest(-100, -45, 75));  
    }
    
    @Test
    void testLargestIntIntInt5() {
        assertEquals(00004, testThis.largest(000001, 000002, 00004));  
    }

    @Test
    void testLargestListOfInteger() {
        ArrayList<Integer> test = new ArrayList<Integer>();
        test.add(4);
        test.add(80);
        test.add(10);
        test.add(15);
        assertEquals(80, testThis.largest(test));
    }
    
    @Test
    void testLargestListOfInteger2() {
        ArrayList<Integer> test = new ArrayList<Integer>();
        test.add(-25);
        test.add(15);
        test.add(48);
        test.add(-72);
        assertEquals(48, testThis.largest(test));
    }
    
    @Test
    void testLargestListOfInteger3() {
        ArrayList<Integer> test = new ArrayList<Integer>();
        test.add(-5);
        test.add(-27);
        test.add(-100);
        test.add(-2048);
        assertEquals(-5, testThis.largest(test));
    }
    
    @Test
    void testLargestListOfInteger4() {
        ArrayList<Integer> test = new ArrayList<Integer>();
        test.add(683);
        test.add(2056);
        test.add(-2081);
        test.add(-67);
        assertEquals(2056, testThis.largest(test));
    }
    
    @Test
    void testLargestListOfInteger5() {
        ArrayList<Integer> test = new ArrayList<Integer>();
        test.add(48);
        test.add(-12);
        test.add(000001);
        test.add(15);
        assertEquals(48, testThis.largest(test));
    }

}
