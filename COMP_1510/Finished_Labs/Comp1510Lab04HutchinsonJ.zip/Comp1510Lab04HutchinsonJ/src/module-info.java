module Comp1510Lab04HutchinsonJ {
    requires org.junit.jupiter.api;
}