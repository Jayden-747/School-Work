package ca.bcit.comp1510.lab04;

/** Creates a student object.
 * @author Jayden H
 * @version 1.0
 */

public class Student {
    
    /** First name of student. */
    private String firstName;
    
    /** Middle name of student. */
    private String lastName;
    
    /** Birth year of student. */
    private Integer yearOfBirth;
    
    /** Student number. */
    private String studentNumber;
    
    /** GPA of student. */
    private Integer gpa;
    
    /** Student object constructor.
     * 
     * @param string firstName
     * @param string2 lastName
     * @param i yearOfBirth
     * @param string3 studentNumber
     * @param j gpa
     */
    public Student(String string, String string2, 
                   int i, String string3, int j) {
        firstName = string;
        lastName = string2;
        yearOfBirth = i;
        studentNumber = string3;
        gpa = j;
    }
    
    /** Getter for first name.
     * 
     * @return First name 
     */
    public String getFirstName() {
        return firstName;
    }
    
    /** Getter for last name.
     * 
     * @return Last Name 
     */
    public String getLastName() {
        return lastName;
    }
    
    /** Getter for year of birth.
     * 
     * @return Last Name 
     */
    public Integer getYearOfBirth() {
        return yearOfBirth;
    }
    
    /** Getter for student number.
     * 
     * @return Student Number
     */
    public String getStudentNumber() {
        return studentNumber;
    }
    
    /** Getter for year of birth.
     * 
     * @return year of birth
     */
    public Integer getBirthYear() {
        return yearOfBirth;
    }
    
    /** Getter for GPA.
     * 
     * @return GPA
     */
    public Integer getGradeAverage() {
        return gpa;
    }
    
    /** Converts values to a string.
     *  
     *  @return toString all values as a string
     */
    public String toString() {
        return firstName + " " + lastName + " " 
             + yearOfBirth + " " + studentNumber + " " 
             + gpa;
    }
    
    /** Setter for first name.
     * 
     * @param string sets the first name
     */
    public void setFirstName(String string) {
        firstName = string;
    }
    
    /** Setter for last name.
     * 
     * @param string sets the last name
     */
    public void setLastName(String string) {
        lastName = string;
    }
    
    /** Setter for year of birth.
     * 
     * @param i sets the year of birth
     */
    public void setBirthYear(int i) {
        yearOfBirth = i;
    }
    
    /** Setter for student number. 
     * 
     * @param string sets the student number
     */
    public void setStudentNumber(String string) {
        studentNumber = string;  
    }
    
    /** Setter for GPA.
     * 
     * @param i sets the GPA
     */
    public void setGradeAverage(int i) {
        gpa = i; 
    }
    
    
    
}
