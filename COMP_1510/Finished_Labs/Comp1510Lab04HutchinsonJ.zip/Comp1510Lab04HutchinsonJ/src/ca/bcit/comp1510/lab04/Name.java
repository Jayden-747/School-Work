package ca.bcit.comp1510.lab04;

/** Class used to make an object out of first, middle, and last name.
 * @author Jayden H
 * @version 1.0
 */

public class Name {
    
    /** Declares the variable for first name. */
    private String firstName;
    
    /** Declares the variable for middle name. */
    private String middleName;
    
    /** Declares the variable for last name. */
    private String lastName;
    
    /** Constructor for the Name Class.
     * 
     * @param newFirstName sets the first name
     * @param newMiddleName sets the middle name
     * @param newLastName sets the last name
     */
    public Name(String newFirstName, String newMiddleName, String newLastName) {
        firstName = newFirstName;
        middleName = newMiddleName;
        lastName = newLastName;
    }
    
    /** Getter for first name.
     * 
     * @return firstName Strings
     */
    public String getFirstName() {
        return firstName;
    }
    
    /** Getter for middle name.
     * 
     * @return middleName String
     */
    public String getMiddleName() {
        return middleName;
    }
    
    /** Getter for last name.
     * 
     * @return lastName String
     */
    public String getLastName() {
        return lastName;
    }
    
    /** Setter for first name.
     * 
     * @param newFirstName sets the first name
     */
    public void setFirstName(String newFirstName) {
        firstName = newFirstName;
    }
    
    /** Setter for middle name.
     * 
     * @param newmiddleName sets the middle name
     */
    public void setMiddleName(String newmiddleName) {
        middleName = newmiddleName;
    }
    
    /** Setter for last name.
     * 
     * @param newlastName sets the last name
     */
    public void setLastName(String newlastName) {
        lastName = newlastName;
    }
    
    /** Converts the Name Class objects to a string.
     * 
     * @return String of Name objects
     */
    public String toString() {
        return firstName + " " + middleName + " " + lastName;
    }
}

    

