package ca.bcit.comp1510.lab04;

/** Represents one die where the number of sides is input.
 * 
 * 
 * @author Lewis & Loftus 9e & Jayden H 
 * @author BCIT
 * @version 2024
 * 
1. We do not need getters or setters for "max" since we 
   set it when we create the object. As well as max being 
   a final variable means we could not change it anyway.
      
2. Yes, because max is declared as an instance variable in the class

3. It makes sense for max to be final so that once the die is created
   it cannot be altered easily
   
4. Max being final but not static means that the number of sides 
   can be chosen when the object is created but cannot be altered

5. Yes
 */
public class MultiDie {
    
    /** Maximum face value. */
    public final int max;

    /** Current value rolled on the die. */
    private int faceValue;
    
    /** Constructor sets the initial face value to 1.
     * 
     * @param numSides Sets how many sides the die has
     */
    public MultiDie(int numSides) {
        max = numSides;
        faceValue = roll();
    }

    /** Rolls this Die and returns the result.
     * 
     * @return faceValue currently displayed on the die
     */
    public int roll() {
        faceValue = (int) (Math.random() * max) + 1;
        return faceValue;
    }

    /** Sets the face value of this Die to the specified value.
     * 
     * @param value Sets the face value to the int given
     */
    public void setFaceValue(int value) {
        faceValue = value;
    }

    /** Returns the face value of this Die as an int.
     * 
     * @return faceValue Returned as an int
     */
    public int getFaceValue() {
        return faceValue;
    }

    /** Returns a String representation of this Die.
     * 
     * @return The face value as a string
     */
    public String toString() {
        String result = Integer.toString(faceValue);
        return result;
    }
}

