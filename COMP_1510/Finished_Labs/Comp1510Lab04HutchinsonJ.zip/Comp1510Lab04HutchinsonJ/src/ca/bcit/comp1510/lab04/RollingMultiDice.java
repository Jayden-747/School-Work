package ca.bcit.comp1510.lab04;

/** Rolls multiple dice.
 * @author Jayden H
 * @version 1.0
 *   
 */

public class RollingMultiDice {

    /** Number of sides of the die. */
    private static final int SIXSIDES = 6;
    
    /** Drives the program.
     * @param args unused
     */
    
    public static void main(String[] args) {
        
        MultiDie dice = new MultiDie(SIXSIDES);
        
        dice.roll();
        System.out.print(dice);
    }

}
