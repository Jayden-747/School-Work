package ca.bcit.comp1510.lab04;

import java.util.Scanner;

/** Creates a Name object from user input.
 * @author Jayden H
 * @version 1.0
 */

public class Names {

    /** Drives the program.
     * 
     * @param args unused
     */
    
    public static void main(String[] args) {
        
        // Scanner for user input
        Scanner scan = new Scanner(System.in);
        
        
        // Asks for users Name through input
        System.out.print("Enter Your First Name: ");
        String firstName = scan.next();
        System.out.print("Enter Your Middle Name: ");
        String middleName = scan.next();
        System.out.print("Enter Your Last Name: ");
        String lastName = scan.next();
        
        
        // Defines the name object
        Name myName = new Name(firstName, middleName, lastName);
        
        
        // Provides each name without the first letter
        String fName = myName.getFirstName().substring(1, firstName.length());
        String mName = myName.getMiddleName().substring(1, middleName.length());
        String lName = myName.getLastName().substring(1, lastName.length());
        
        
        // Capitalizes first letter of first name
        String capital = myName.getFirstName().substring(0, 1).toUpperCase();
        String capitalFirstName = capital;
        // Cancatanates the first letter with the name
        myName.setFirstName(capitalFirstName + fName);

        
        // Capitalizes first letter of middle name
        capital = myName.getMiddleName().substring(0, 1).toUpperCase();
        String capitalMiddleName = capital;
        // Cancatanates the first letter with the name
        myName.setMiddleName(capitalMiddleName + mName);
        
        
        // Capitalizes first letter of last name 
        capital = myName.getLastName().substring(0, 1).toUpperCase();
        String capitalLastName = capital;
        // Cancatanates the first letter with the name
        myName.setLastName(capitalLastName + lName);
        
        
        // Assigns the name object to a string
        String fullName = myName.toString();
        
        
        // Prints the final result
        System.out.print(fullName);
        
        scan.close();
    }

}
