package ca.bcit.comp1510.lab04;

import java.util.Scanner;

/** Changes bases of an integer and adds 2 values together.
 * @author Jayden H
 * @version 1.0
 */

public class IntegerWrapper {

    /** Drives the program.
     * @param args unused
     */
    
    public static void main(String[] args) {
        
        // Scanner for user input
        Scanner scan = new Scanner(System.in);
        
        // Prompts for an input
        System.out.print("Enter an Integer: ");
        Integer userInt = scan.nextInt();
        
        // Reads input and changes the base to print
        System.out.println("\nEntered Value: " + userInt);
        System.out.println("Binary Value: " + Integer.toBinaryString(userInt));
        System.out.println("Octal Value: " + Integer.toOctalString(userInt));
        System.out.println("Hex Value: " + Integer.toHexString(userInt));
    
        // Prints Min/Max values of the Integer Class
        System.out.println("\nInteger Class Max Value: " + Integer.MAX_VALUE);
        System.out.println("Integer Class Min Value: " + Integer.MIN_VALUE);
        
        // Prompts for 2 values 
        System.out.print("\nEnter your first value: ");
        String value1 = scan.next();
        System.out.print("Enter your second value: ");
        String value2 = scan.next();
        
        // Converts the value strings to integers
        int value1Int = Integer.parseInt(value1);
        int value2Int = Integer.parseInt(value2);
        
        // Prints the added value of the integers
        System.out.println(value1Int + value2Int);
        
        scan.close();
    }

}
